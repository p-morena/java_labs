package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {
        // write your code here
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new WikiHow();
            }
        });
    }

    public static class WikiHow implements ActionListener {
        JLabel jlab;

        public WikiHow() {

            JFrame jfram = new JFrame("Menu Demo");
            jfram.setLayout(new FlowLayout());
            jfram.setSize(200, 200);

            jfram.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jlab = new JLabel();

            JMenuBar jmb = new JMenuBar();
            JMenu jmFile = new JMenu("File");
            JMenuItem jmiOpen = new JMenuItem("Open");
            JMenuItem jmiClose = new JMenuItem("Close");
            JMenuItem jmiSave = new JMenuItem("Save");
            JMenuItem jmiExit = new JMenuItem("Exit");

            jmFile.add(jmiOpen);
            jmFile.add(jmiClose);
            jmFile.add(jmiSave);
            jmFile.addSeparator();
            jmFile.add(jmiExit);
            jmb.add(jmFile);

            JMenu jmOptions = new JMenu("Options");
            JMenu jmColors = new JMenu("Colors");
            JMenuItem jmiRed = new JMenuItem("Red");
            JMenuItem jmiGreen = new JMenuItem("Green");
            JMenuItem jmiBlue = new JMenuItem("Blue");

            jmColors.add(jmiRed);
            jmColors.add(jmiGreen);
            jmColors.add(jmiBlue);
            jmOptions.add(jmColors);

            JMenu jmPriority = new JMenu("Priority");
            JMenuItem jmiHigh = new JMenuItem("High");
            JMenuItem jmiLow = new JMenuItem("Low");

            jmPriority.add(jmiHigh);
            jmPriority.add(jmiLow);
            jmOptions.add(jmPriority);

            JMenuItem jmiReset = new JMenuItem("Reset");
            jmOptions.addSeparator();
            jmOptions.add(jmiReset);

            jmb.add(jmOptions);

            JMenu jmHelp = new JMenu("Help");

            JMenuItem jmiAbout = new JMenuItem("About");
            jmHelp.add(jmiAbout);
            jmb.add(jmHelp);


            jmiOpen.addActionListener(this);
            jmiClose.addActionListener(this);
            jmiSave.addActionListener(this);
            jmiExit.addActionListener(this);
            jmiRed.addActionListener(this);
            jmiGreen.addActionListener(this);
            jmiBlue.addActionListener(this);
            jmiHigh.addActionListener(this);
            jmiLow.addActionListener(this);
            jmiReset.addActionListener(this);
            jmiAbout.addActionListener(this);
            jfram.add(jlab);
            jfram.setJMenuBar(jmb);
            jfram.setVisible(true);

        }

        public void actionPerformed(ActionEvent e) {
            String comStr = e.getActionCommand();

            if (comStr.equals("Exit")) System.exit(0);
            jlab.setText(comStr + "Selected");

        }
    }
}