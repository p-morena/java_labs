package com.company;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {
	// write your code here
WikiHow myApplication = new WikiHow();
myApplication.setLocation(10,10);
myApplication.setSize(300,300);
myApplication.setVisible(true); }


   public static class WikiHow extends JFrame implements ActionListener {
        JButton myButton = new JButton("Button");
        JCheckBox myCheckBox = new JCheckBox("Check");

        JTextArea myText = new JTextArea("My text");

        JPanel bottomPanel = new JPanel();

        JPanel holdAll = new JPanel();

        public WikiHow() {
            bottomPanel.setLayout(new FlowLayout());
            bottomPanel.add(myCheckBox);
            bottomPanel.add(myButton);
            holdAll.setLayout(new BorderLayout());
            holdAll.add(bottomPanel, BorderLayout.SOUTH);
            holdAll.add(myText, BorderLayout.CENTER);
            getContentPane().add(holdAll, BorderLayout.CENTER);
            myButton.addActionListener(this);
            myCheckBox.addActionListener(this);

            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        }

public void actionPerformed(ActionEvent e){
            if(e.getSource()==myButton){
                myText.setText("A button click");
            } else if(e.getSource()==myCheckBox){
                myText.setText("The checlbox state changed to"+myCheckBox.isSelected());}
            else{myText.setText("E..?");
            }
}
    }

}









