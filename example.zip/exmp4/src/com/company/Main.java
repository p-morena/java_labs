package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;



public class Main {

    public static void main(String[] args) {
	// write your code here
        JFrame frame = new JFrame("Приклад");
        FontsList appl = new FontsList();
        appl.init();
        appl.start();
        frame.getContentPane().add(appl);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,300);
        frame.setVisible(true);

    }

    public static class FontsList extends JApplet{
Font f[];
int count=0, x=10, y=20;
double w, h;
int tek =0;

public FontsList(){}

@Override
        public void start(){
    Dimension d = getSize();
    w=d.getWidth();
    h=d.getHeight();
}

@Override
        public void init(){
   GraphicsEnvironment ge= GraphicsEnvironment.getLocalGraphicsEnvironment();
    f=ge.getAllFonts();
    MouseListener ml = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
            repaint();
        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {

        }
    };
    addMouseListener(ml);
    resize(800,300);
    }

@Override
        public void paint (Graphics g){
    g.clearRect(0,0,(int)w, (int)h);
    int i;
    for(i=tek; i<f.length; i++){
        String s= "";
        s+=f[i].getFontName();
        s+="";

        s+=f[i].getFamily();
        s+="";

        s+=f[i].getSize();
        s+="";

        s+=f[i].toString();
g.drawString(s, x, y);
y=y+20;
if(y>=h){
    y=20;
    break;
}
        if(i==f.length){
            i=0;
            y=20;
        }
tek=i;
                }


         }

     }

}



