
package com.company;
import javax.swing.*;


public class Main {

    public static void main(String[] args) {
	// write your code here
JFrame f = new JFrame("Hello, World!");
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        f.add(new JLabel("Hello world!"));
        f.pack();
        f.setVisible(true);

    }
}
