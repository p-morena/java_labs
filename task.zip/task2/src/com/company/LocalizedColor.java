package com.company;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import java.awt.*;
import java.util.Arrays;

@Getter
@RequiredArgsConstructor
public enum LocalizedColor {
    RED("red", Color.RED),
    BLUE("blue", Color.BLUE),
    GREEN("green", Color.GREEN),
    BLACK("black", Color.BLACK);

    private final String localized;
    private final Color color;

    public static LocalizedColor fromLocalized(String localized) {
        return Arrays.stream(LocalizedColor.values())
                .filter(localizedColor -> localizedColor.getLocalized().equals(localized))
                .findAny()
                .orElseThrow();
    }
}
