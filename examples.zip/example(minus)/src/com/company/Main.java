package com.company;
import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        // write your code here
        JOptionPane.showMessageDialog(null,"Студент Петренко мк-12-т1");
        String string_a=JOptionPane.showInputDialog("Введите первое число");
        int  a=Integer.parseInt(string_a);

        String string_b=JOptionPane.showInputDialog("Введите второе число");
        int  b=Integer.parseInt(string_a);

        int sum=a+b;
        int min=a-b;
        double div=(double)a/(double)b;
        int  mul=a*b;

        String msg = "Ariph operation";
        msg +="\nSum"+sum+"\n";
        msg+="\nMin"+min+"\n";
        msg +="\nDiv"+div+"\n";
        msg +="\nMultiply"+mul+"\n";

        JOptionPane.showMessageDialog(null,msg);
        JOptionPane.showMessageDialog(null,"Successful completed!");
    }
}
